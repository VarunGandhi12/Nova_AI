import pygame # Import pygame for handling audio playback
import os # Import os for file path operations
import random # Import random for random choices
import edge_tts # Import edge_tts for text-to-speech functionality
import asyncio # Import asyncio for asynchronous operations
from dotenv import dotenv_values # Import dotenv_values for reading environment variables

# Load environment variables from .env file
env_vars = dotenv_values(".env")
assistant_voice = env_vars.get("AssistantVoice") # Get the assistant voice from the .env file

# Asynchronous function to convert text to an audio file
async def TextToAudioFile(text) -> None:
    file_path = r"Data\speech.mp3" # Define the path where the speech file will be saved

    # Check if the speech file already exists
    if os.path.exists(file_path):
        os.remove(file_path) # If it exists, remove the old speech file to avoid overwriting errors
    
    # Create the communication object to generate speech
    communicate= edge_tts.Communicate(text=text,voice=assistant_voice, pitch='+5Hz',rate='+13%')
    await communicate.save(r"Data\speech.mp3") # Save the generated speech as an MP3 file

# Function to handle Text-to-Speech (TTS) functionality
def TextToSpeech(Text,func=lambda r=None: True):
    while True:
        try:
            # Convert text to audio asyncchronously
            asyncio.run(TextToAudioFile(Text))
            
            # Inirialize pygame mixer for audio playback
            pygame.mixer.init()
            
            # Load the speech.mp3 file that was created by TextToSpeech()
            pygame.mixer.music.load(r"Data/speech.mp3")
            pygame.mixer.music.play() # Play the audio

            # Keep checking if the audio is still playing or the function stops
            while pygame.mixer.music.get_busy():
                if func()==False:
                    break
                pygame.time.Clock().tick(10) # Control the playback speed - tick at 10 frames per second
            
            return True # Audio played successfully

        except Exception as e:
            print(f"Error in TextToSpeech.py : {e}")
        
        finally:
            try:
                # Call the callback function with False to indicate TTS has ended
                func(False)
               
                pygame.mixer.music.stop() # Stop any currently playing audio
                pygame.mixer.quit() # Clean up and close the pygame mixer system
            except Exception as e:
                print(f"Error in TTS file -finally block: {e}")

# Function to manage TTS with additional response for long text
def TTS(Text, func= lambda r= None : True):
    Data = str(Text).split('.')  # Split the sentences by "." to form list of sentences

    # List of predined cases of long texts
    responses = [
        "The rest of the result has been printed to the chat screen, kindly check it out sir.",
        "The rest of the text is now on the chat screen, sir, please check it.",
        "You can see the rest of the text on the chat screen, sir.",
        "The remaining part of the text is now on the chat screen, sir.",
        "Sir, you'll find more text on the chat screen for you to see.",
        "The rest of the answer is now on the chat screen, sir.",
        "Sir, please look at the chat screen, the rest of the answer is there.",
        "You'll find the complete answer on the chat screen, sir.",
        "The next part of the text is on the chat screen, sir.",
        "Sir, please check the chat screen for more information.",
        "There's more text on the chat screen for you, sir.",
        "Sir, take a look at the chat screen for additional text.",
        "You'll find more to read on the chat screen, sir.",
        "Sir, check the chat screen for the rest of the text.",
        "The chat screen has the rest of the text, sir.",
        "There's more to see on the chat screen, sir, please look.",
        "Sir, the chat screen holds the continuation of the text.",
        "You'll find the complete answer on the chat screen, kindly check it out sir.",
        "Please review the chat screen for the rest of the text, sir.",
        "Sir, look at the chat screen for the complete answer."
    ]

    # If the text is more than 4 sentences and 250 characters (Too Long), add a response message
    if len(Data)>4 and len(Text)>=250:
        TextToSpeech(" ".join(Text.split(".")[0:2]) + ". " + random.choice(responses), func)
    
    # Otherwise just play the whole text
    else:
        TextToSpeech(Text,func)

# Main block
if __name__=="__main__":
    while True:
        TTS(input("Prompt: "))