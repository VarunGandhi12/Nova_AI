from groq import Groq # Import Groq library to use groq model API
from json import load, dump # Importing functions to read and write JSON files
import datetime # Importing datetime to get the current date and time
from dotenv import dotenv_values # Importing dotenv_values to read environment variables from .env file

# Load environment variables from .env file
env_vars = dotenv_values(".env")

# Retrieve specific environmental variables for username, assistant name and API key
GroqAPIkey= env_vars.get("GroqAPIKey")
Username= env_vars.get("Username")
Assistantname= env_vars.get("AssistantName")

# Initialize Groq client with API key
client= Groq(api_key=GroqAPIkey)
messages=[] # Initialize an empty list to store messages

#Define a system message thatprovides context to the AT chatbot about its role and behaviour
System = f"""
You are {Assistantname}, an advanced AI assistant focused on providing accurate, concise, and helpful responses. You also have real-time up-to-date information from the internet.
Here are your core behaviors:
1. Communication Style:
- Provide direct, clear answers without unnecessary elaboration
- Always respond in English, regardless of the query language
- Maintain a professional yet friendly tone
2. Response Guidelines:
- Focus solely on answering the specific question asked
- Avoid mentioning AI capabilities or training data
- Only provide time/date information when explicitly requested
- Do not include explanatory notes or disclaimers
3. Information Handling:
- Leverage provided real-time data when relevant
- Ensure responses are accurate and up-to-date
- Present information in a structured, easy-to-read format
Your goal is to be helpful while staying within these parameters. Interact as {Assistantname} speaking with {Username}.
"""

# List of sytem instructions for the chatbot
SystemChatbot=[
    {"role":"system","content":System}
]

# Load the chat log from a JSON file
try:
    with open(r"Data\ChatLog.json","r") as f:
        messages=load(f) #load existing messages from the chat log
except FileNotFoundError:
    #if file doesn't exist, create an empty JSON file to store chat logs.
    with open(r"Data\ChatLog.json","w") as f:
        dump([],f)

#Function to get real-time date and time information
def RealtimeInformation():
    current_date_time= datetime.datetime.now() # Get the current date and time
    day= current_date_time.strftime("%A") # Day of the week
    date= current_date_time.strftime("%d") # Day of the month
    month= current_date_time.strftime("%B") # Full month name
    year= current_date_time.strftime("%Y") # Year
    hour= current_date_time.strftime("%H") # Hour in 24-hour format
    minute= current_date_time.strftime("%M") # Minute
    second= current_date_time.strftime("%S") # Second

    # Format the information into a string
    data= f"Please use this real-time information if needed,\n"
    data+= f"Day: {day}\nDate: {date}\nMonth: {month}\nYear: {year}\n"
    data+= f"Time: {hour} hours: {minute} minutes: {second} seconds"
    return data

#Function to modify chatbot's response for better formatting
def RespModifier(Answer):
    lines= Answer.split("\n") # Split the response into lines
    non_empty_lines= [line for line in lines if line.strip()] # Remove empty lines
    modified_resp= "\n".join(non_empty_lines) # Joining cleaned lines together 
    return modified_resp

# Main chatbot Function
def Chatbot(Query):
    """ This function sends a query to the chatbot and returns the response. """
    try:
        # Load the existing chat history from the JSON file
        with open(r"Data\ChatLog.json","r") as f:
            messages = load(f)
        
        # Appending user query to messages list
        messages.append({"role":"user","content":f"{Query}"})

        # Request to Groq API for a response
        completion= client.chat.completions.create(
            model= "llama3-70b-8192",  # Specify the LLM model to use
            messages= SystemChatbot + [{"role": "system","content": RealtimeInformation()}] + messages, # Combine system instructions, real-time info, and chat history
            max_tokens= 1024, # Limit maximum tokens (words/characters) in the response
            temperature=0.7, # Controls randomness (0.0 = deterministic, 1.0 = most random)
            top_p=1,  # Controls diversity of responses (1.0 = consider all tokens)
            stream=True, # Get response piece by piece instead of all at once
            stop=None  # Allow model to determine when to stop
        )
        Answer='' # Empty string to store the AI's response

        # Get each piece of the response as it comes in
        for chunk in completion:
            if chunk.choices[0].delta.content: # Check for content present in current chunk
                Answer+=chunk.choices[0].delta.content # Append the content to the answer

        # Clean up the response by removing any end markers
        Answer = Answer.replace("</s>", "")
        
        # Add the AI's response to the chat history
        messages.append({"role":"assistant","content":Answer})
        
        # Save the updated chat history back to the file
        with open(r"Data\ChatLog.json","w") as f:
            dump(messages, f, indent=4)
            
        # Return the cleaned up response
        return RespModifier(Answer=Answer)

    except Exception as e:
        # If any error occurs during chatbot operation:
        # 1. Print the error message for debugging
        # 2. Reset the chat log to empty
        # 3. Try the query again with fresh chat history

        print(f"Error: {e}")
        with open(r"Data\ChatLog", "w") as f:
            dump([],f,indent=4)
        return Chatbot(Query=Query)

# Main program
if __name__=="__main__":
    while True:
        user_input= input("You: ")  # Get input from user with a prompt
        response= Chatbot(Query=user_input)  # Send user's message to chatbot and get respons
        
        # Display chatbot's response
        print(f"Chatbot: {response}")