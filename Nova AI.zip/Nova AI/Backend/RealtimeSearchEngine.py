from googlesearch import search # Import Google search functionality for web searches
from groq import Groq # Import Groq library to interact with Groq's AI models
from json import load, dump # Import JSON functions to read (load) and write (dump) JSON files
import datetime # Import datetime module to handle date and time operations
from dotenv import dotenv_values # Import dotenv_values to load environment variables from .env file

# Load environmental variables from .env file.
env_vars= dotenv_values(".env")

# Retrieve specific environmental variables for username, assistant name and API key
GroqAPIkey= env_vars.get("GroqAPIKey")
Username= env_vars.get("Username")
Assistantname= env_vars.get("AssistantName")

# Initialize Groq client with API key
client= Groq(api_key=GroqAPIkey)

# Define the system instruction for chatbot

System = f"""
You are {Assistantname}, an advanced AI assistant with real-time access to up-to-date information from the internet. Your primary goal is to provide accurate, concise, and helpful responses in a natural and professional manner.
Here are your core guidelines:
1. Communication Style:
- Use proper grammar, punctuation, and capitalization.
- Maintain a professional yet approachable tone.
- Always respond in English, regardless of the query language.
2. Response Guidelines:
- Focus on answering the specific question asked.
- Avoid unnecessary elaboration or off-topic information.
- Do not mention AI capabilities or training data.
- Provide time/date information only when explicitly requested.
- Provide sources and references when explicitly asked by the user, such as "what are your sources" or "give me references".
3. Information Handling:
- Utilize real-time data when relevant.
- Ensure responses are accurate and up-to-date.
- Present information in a clear and structured format.
Your objective is to assist {Username} effectively while adhering to these guidelines.
"""

# Try to load the chatlog from JSON file
try:
    with open(r"Data\ChatLog.json","r") as f:
        messages = load(f)
except FileNotFoundError:  
    with open(r"Data\ChatLog.json","w") as f:
        dump([],f)

# Function to perform a Google search and format the results.
def GoogleSearch(query):
    results=list(search(query,advanced=True,num_results=5))
    Answer= f"The search results for {query} are:\n[start]\n"
    for i in results:
        Answer += f"Title: {i.title}\nDescription: {i.description}\n\n"
    Answer+= "[end]"
    return Answer

#Function to clean up the answer by removing empty lines
def AnswerModifier(Answer):
    lines= Answer.split('\n')
    non_empty_lines= [line for line in lines if line.strip()]
    modified_answer='\n'.join(non_empty_lines)
    return modified_answer

# Predefined chatbot conversation system message and an initial user message
SystemChatBot=[
    {"role":"system","content":System},
    {"role":"user","content":"Hi"},
    {"role":"assistant","content":"Hello, how can i help you?"}
]

# Function to get real-time information like date time
def DateTimeInformation():
    data=""

    current_date_time= datetime.datetime.now() # Get the current date and time
    day= current_date_time.strftime("%A") # Day of the week
    date= current_date_time.strftime("%d") # Day of the month
    month= current_date_time.strftime("%B") # Full month name
    year= current_date_time.strftime("%Y") # Year
    hour= current_date_time.strftime("%H") # Hour in 24-hour format
    minute= current_date_time.strftime("%M") # Minute
    second= current_date_time.strftime("%S") # Second

    data+= f"Use This Real-time information if needed:\n"
    data+= f"Day: {day}\n"
    data+= f"Date: {date}\n"
    data+= f"Month: {month}\n"
    data+= f"Year: {year}\n"
    data+= f"Time: {hour}, {minute} minutes, {second} seconds.\n"
    return data

# Function to handle real-time search and response generation
def RealtimeSearchEngine(prompt):
    global SystemChatBot, messages

    # Load the chat log from the JSON file
    with open(r"Data\ChatLog.json","r") as f:
        messages= load(f)
    messages.append({"role":"user","content":f"{prompt}"})

    # Add Google search results to system chatbot messages
    SystemChatBot.append({"role":"system","content": GoogleSearch(prompt)})

    # Generate a response using Groq client
    completion= client.chat.completions.create(
        model="llama3-70b-8192",
        messages=SystemChatBot + [{"role":"system","content":DateTimeInformation()}] +messages,
        temperature=0.7,
        max_tokens= 2048,
        top_p=1,
        stream=True,
        stop=None
    )

    Answer=""

    #Concatenate responsechunks from the streaming output
    for chunk in completion:
        if chunk.choices[0].delta.content:
            Answer += chunk.choices[0].delta.content
    
    # Clean up the response
    Answer=Answer.strip().replace("</s>","")
    messages.append({"role":"assistant","content":Answer})

    # Save the updated Chat Log back to the JSON file
    with open(r"Data\ChatLog.json","w") as f:
        dump(messages,f,indent=4)
    # Remove the most recent message from the chatbot conversation
    SystemChatBot.pop()
    return AnswerModifier(Answer=Answer)

# Main function to run the chatbot
if __name__ == "__main__":
    while True:
        prompt= input("You: ")
        print(f"Chatbot(R): {RealtimeSearchEngine(prompt=prompt)}")

